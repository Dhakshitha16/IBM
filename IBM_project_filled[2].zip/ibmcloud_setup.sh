#!/bin/bash
ibmcloud login --sso
ibmcloud cr login
ibmcloud target -g Default
ibmcloud cr namespace-add mynamespace
