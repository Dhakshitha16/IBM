# IBM Cloud Microservices Project

This repository contains the setup for deploying a microservices-based application on IBM Cloud using Docker, Kubernetes, and Ansible.